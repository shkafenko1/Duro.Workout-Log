#ifndef TRAINING_DIARY_TRANINGHOOKS_H
#define TRAINING_DIARY_TRANINGHOOKS_H
void createTraning();
void reportTraining();
void adviceTraning();
#endif