#ifndef TRAINING_DIARY_SYSTEMTECH_H
#define TRAINING_DIARY_SYSTEMTECH_H
void setBackgorundColor();
void setRussianLanguage();
void ClearConsole();
#endif