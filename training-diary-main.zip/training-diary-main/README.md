# training-diary
Дневнпик тренировок на C
